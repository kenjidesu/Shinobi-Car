Description: modified NewPing library (ultrasonic sensors)

Original author: Tim Eckel

Homepage: https://code.google.com/p/arduino-new-ping/
